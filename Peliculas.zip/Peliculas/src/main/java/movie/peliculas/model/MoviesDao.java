package movie.peliculas.model;

import movie.peliculas.utils.Conex;

import java.sql.*;
import java.util.Base64;
import java.util.LinkedList;
import java.util.List;

public class MoviesDao {

    Connection conn;
    PreparedStatement pstm;
    CallableStatement cstm;
    ResultSet rs;

    public List<MoviesBean> findAll() {
        List<MoviesBean> movieslist = new LinkedList<>();
        MoviesBean movie;
        try {
            conn = new Conex().getConnection();
            String query = "SELECT * FROM cinema";
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()) {
                movie = new MoviesBean ();
                movie.setIdmovies(rs.getInt(1));
                movie.setName(rs.getString(2));
                movie.setDescription(rs.getString(3));
                movie.setPublish_date(rs.getDate(4));
                movie.setActors(rs.getString(5));
                movie.setDurations(rs.getInt(6));
                movie.setRanking(rs.getDouble(7));
             //   byte[] img = rs.getBytes(8);
               // String setimage = Base64.getEncoder().encodeToString(img);
             //   movie.setImage(setimage);
                movieslist.add(movie);
            }
        }  catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            System.err.printf("Close find all ");
        }

        for (MoviesBean m:  movieslist ) {
            System.out.println(m.toString());
        }

        return movieslist;
    }

    public static void main(String[] args) {
        new MoviesDao().findAll();
    }

    /*
    *
    *
    *
    * CREATE TABLE `cinema` (
  `idmovies` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_croatian_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_croatian_ci,
  `publish_date` date DEFAULT NULL,
  `actors` varchar(45) COLLATE utf8_croatian_ci DEFAULT NULL,
  `durations` int DEFAULT NULL,
  `ranking` double DEFAULT NULL,
  `image` mediumblob,
  PRIMARY KEY (`idmovies`)
) ;
  */

}

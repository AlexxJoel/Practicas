package movie.peliculas.model;

import java.io.InputStream;
import java.util.Date;

public class MoviesBean {
    private int idmovies;
    private String name;
    private String description;
    private Date publish_date;
    private String actors;
    private int durations;
    private double ranking;
    private String image;
    private InputStream imageget;


    public MoviesBean() {
    }

    public MoviesBean(int idmovies, String name, String description, Date publish_date, String actors, int durations, double ranking, String image, InputStream imageget) {
        this.idmovies = idmovies;
        this.name = name;
        this.description = description;
        this.publish_date = publish_date;
        this.actors = actors;
        this.durations = durations;
        this.ranking = ranking;
        this.image = image;
        this.imageget = imageget;
    }

    public int getIdmovies() {
        return idmovies;
    }

    public void setIdmovies(int idmovies) {
        this.idmovies = idmovies;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getPublish_date() {
        return publish_date;
    }

    public void setPublish_date(Date publish_date) {
        this.publish_date = publish_date;
    }

    public String getActors() {
        return actors;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }

    public int getDurations() {
        return durations;
    }

    public void setDurations(int durations) {
        this.durations = durations;
    }

    public double getRanking() {
        return ranking;
    }

    public void setRanking(double ranking) {
        this.ranking = ranking;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public InputStream getImageget() {
        return imageget;
    }

    public void setImageget(InputStream imageget) {
        this.imageget = imageget;
    }

    //--------------------------SEE------------------------------------

    @Override
    public String toString() {
        return "MoviesBean{" +
                "idmovies=" + idmovies +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", publish_date=" + publish_date +
                ", actors='" + actors + '\'' +
                ", durations=" + durations +
                ", ranking=" + ranking +
                ", image='" + image + '\'' +
                ", imageget=" + imageget +
                '}';
    }
}
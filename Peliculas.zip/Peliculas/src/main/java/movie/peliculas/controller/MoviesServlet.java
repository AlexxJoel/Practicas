package movie.peliculas.controller;

import movie.peliculas.model.MoviesBean;
import movie.peliculas.service.MoviesServices;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "MoviesServlet", value = "/MoviesServlet")
public class MoviesServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        MoviesServices sevrmovie = new MoviesServices();
        MoviesBean  moviues = new MoviesBean();
        String action = request.getParameter("action");
        if (action == null){
            action = "listar";
        }
        String    Url =  "/index.jsp";
        System.out.println(action);
        switch (action){

            case "listar":
                List<MoviesBean> movies = sevrmovie.findALL();
                request.setAttribute("listmovies", movies);
                    Url = "/index.jsp";
                System.out.println(movies.size());
                break;
            case "save":
                Url = "/createMovie.jsp";
                break;

            default:
        }
        request.getRequestDispatcher(Url).forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}

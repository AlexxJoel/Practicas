package movie.peliculas.service;

import movie.peliculas.model.MoviesBean;
import movie.peliculas.model.MoviesDao;

import java.util.List;

public class MoviesServices {

    MoviesDao movies = new MoviesDao();
    MoviesBean moviesBEAN = new MoviesBean();

    public List<MoviesBean> findALL(){
        return movies.findAll();
    }



}